import type { SectionId } from "./types";

export type Hotspot = {
  id: string;
  x: number;
  y: number;
};

/** Percent positions on /images/diagram.jpg — 3/4 rear-right Rewaco HS4. */
export const HOTSPOTS: Hotspot[] = [
  { id: "1", x: 74, y: 10 },
  { id: "2", x: 68, y: 16 },
  { id: "3", x: 71, y: 20 },
  { id: "4", x: 58, y: 28 },
  { id: "5", x: 76, y: 22 },
  { id: "6", x: 80, y: 26 },
  { id: "7", x: 83, y: 30 },
  { id: "8", x: 81, y: 35 },
  { id: "9", x: 84, y: 42 },
  { id: "10", x: 87, y: 50 },
  { id: "11", x: 73, y: 28 },
  { id: "12", x: 88, y: 58 },
  { id: "13", x: 86, y: 68 },
  { id: "14", x: 82, y: 78 },
  { id: "15", x: 70, y: 52 },
  { id: "16", x: 66, y: 60 },
  { id: "17", x: 52, y: 62 },
  { id: "18", x: 62, y: 64 },
  { id: "19", x: 76, y: 48 },
  { id: "20", x: 56, y: 38 },
  { id: "21", x: 60, y: 42 },
  { id: "22", x: 10, y: 62 },
  { id: "23", x: 16, y: 74 },
  { id: "24", x: 8, y: 48 },
  { id: "25", x: 22, y: 58 },
  { id: "26", x: 28, y: 64 },
  { id: "27", x: 38, y: 58 },
  { id: "28", x: 6, y: 32 },
  { id: "32", x: 48, y: 18 },
  { id: "49", x: 34, y: 22 },
  { id: "62", x: 44, y: 34 },
];

export const SECTION_TONE: Record<SectionId, string> = {
  etat: "text-foreground",
  elec: "text-accent",
  freinage: "text-bad",
  essai: "text-warn",
  moteur: "text-ok",
  alim: "text-warn",
  divers: "text-muted-foreground",
};
