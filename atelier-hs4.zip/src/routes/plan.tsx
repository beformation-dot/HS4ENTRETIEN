import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { StatusToggle } from "@/components/status-toggle";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { HOTSPOTS } from "@/lib/diagram";
import { ITEM_BY_ID, ITEMS, STATUS_META } from "@/lib/checklist";
import { emptyInspection, useGarage } from "@/lib/store";
import type { ItemStatus } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/plan")({ component: PlanPage });

function PlanPage() {
  const inspections = useGarage((s) => s.inspections);
  const vehicle = useGarage((s) => s.vehicle);
  const addInspection = useGarage((s) => s.addInspection);
  const setItemStatus = useGarage((s) => s.setItemStatus);
  const [activeId, setActiveId] = useState<string>("1");

  const draft =
    inspections.find((i) => i.status === "draft") ?? inspections[0] ?? null;

  const item = ITEM_BY_ID[activeId] ?? ITEMS[0];
  const status = draft?.items[item.id];

  const statusById = useMemo(() => {
    const map: Record<string, ItemStatus | undefined> = {};
    if (draft) {
      for (const h of HOTSPOTS) map[h.id] = draft.items[h.id];
    }
    return map;
  }, [draft]);

  function ensureDraft() {
    if (draft) return draft.id;
    const insp = emptyInspection(vehicle);
    addInspection(insp);
    return insp.id;
  }

  function onStatus(next: ItemStatus | undefined) {
    const id = ensureDraft();
    setItemStatus(id, item.id, next);
  }

  return (
    <AppShell>
      <p className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
        Repérage
      </p>
      <h1 className="mt-1 text-3xl">Plan du trike</h1>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">
        Touchez un numéro pour le localiser, comme sur le schéma du formulaire.
        L'état se reporte sur la check-list en cours.
      </p>

      <div className="mt-5 overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
        <div className="relative">
          <img
            src="/images/diagram.jpg"
            alt="Schéma Rewaco HS4 vue trois-quarts arrière droite"
            className="w-full"
          />
          {HOTSPOTS.map((h) => {
            const st = statusById[h.id];
            const on = h.id === activeId;
            return (
              <button
                key={h.id}
                type="button"
                onClick={() => setActiveId(h.id)}
                style={{ left: `${h.x}%`, top: `${h.y}%` }}
                className={cn(
                  "absolute flex size-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-display text-xs tabular-nums shadow-sm transition-[transform,background-color] duration-150",
                  on ? "z-10 scale-110 bg-primary text-primary-foreground" : pinTone(st),
                )}
                aria-label={`Point ${h.id}`}
              >
                {h.id}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-display text-2xl tabular-nums">{item.num}</p>
            <h2 className="mt-1 text-xl normal-case tracking-normal">
              {item.label}
            </h2>
          </div>
          {status ? (
            <Badge
              variant={status === "ok" ? "ok" : status === "warn" ? "warn" : "fail"}
            >
              {STATUS_META[status].short}
            </Badge>
          ) : (
            <Badge>Non noté</Badge>
          )}
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <StatusToggle value={status} onChange={onStatus} />
          {draft ? (
            <Button variant="outline" size="sm" asChild>
              <Link to="/controle/$id" params={{ id: draft.id }}>
                Ouvrir la fiche
              </Link>
            </Button>
          ) : (
            <p className="text-xs text-muted-foreground">
              Le premier point crée un brouillon.
            </p>
          )}
        </div>
      </div>

      <section className="mt-6 grid gap-3 sm:grid-cols-2">
        <figure className="overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
          <img
            src="/images/soufflet.jpg"
            alt="Soufflet de trompette arrière"
            className="h-44 w-full object-cover"
          />
          <figcaption className="p-4">
            <p className="text-xs tracking-[0.14em] text-muted-foreground uppercase">
              Point 25
            </p>
            <p className="mt-1 text-sm">Soufflets des trompettes</p>
          </figcaption>
        </figure>
        <figure className="overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
          <img
            src="/images/engine.jpg"
            alt="Moteur Cox aircooled"
            className="h-44 w-full object-cover"
          />
          <figcaption className="p-4">
            <p className="text-xs tracking-[0.14em] text-muted-foreground uppercase">
              Points 47–61
            </p>
            <p className="mt-1 text-sm">Moteur Cox — carbu, allumage, courroie</p>
          </figcaption>
        </figure>
      </section>

      <div className="mt-6 flex flex-wrap gap-4 text-xs text-muted-foreground">
        <Legend swatch="bg-ok" label="Bon état" />
        <Legend swatch="bg-warn" label="Mauvais état" />
        <Legend swatch="bg-bad" label="HS / ne fonctionne pas" />
        <Legend swatch="bg-muted" label="Non noté" />
      </div>
    </AppShell>
  );
}

function pinTone(st: ItemStatus | undefined) {
  if (st === "ok") return "bg-ok text-ok-fg";
  if (st === "warn") return "bg-warn text-warn-fg";
  if (st === "fail") return "bg-bad text-bad-fg";
  return "bg-ink/80 text-paper";
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className={cn("size-2.5 rounded-full", swatch)} />
      {label}
    </span>
  );
}
